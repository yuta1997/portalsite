
	$(document).ready(function(){
		$("div#item_semi").click(function(){
			$("div#contents_semi").slideUp(300);
			$(this).next().slideDown(300)
		});
	});


	$(document).ready(function(){
		$("div#item_teach").click(function(){
			$("div#contents_teach").slideUp(300);
			$(this).next().slideDown(300)
		});
	});

	