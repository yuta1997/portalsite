
    $(document).ready(function(){

        $('#slide').hide(); //初期では非表示

        $('#tags span').click(function() {

            if($(this).hasClass('active')){

                $('#slide').hide();

                $($(this).find('#slide').attr('href')).fadeOut();

                $('#slide').removeClass('active');

            }else{

                $('#slide').removeClass('active');

                $('#slide').hide();
                $($(this).find('#slide').attr('href')).fadeIn();

                $(this).addClass('active');

            }

        })

    });

    $(document).ready(function(){

        $('#slide2').hide(); //初期では非表示

        $('#tags span').click(function() {

            if($(this).hasClass('active')){

                $('#slide2').hide();

                $($(this).find('#slide2').attr('href')).fadeOut();

                $('#slide2').removeClass('active');

            }else{

                $('#slide2').removeClass('active');

                $('#slide2').hide();
                $($(this).find('tags').attr('href')).fadeIn();

                $(this).addClass('active');

            }

        })

    });

    $(document).ready(function(){

        $('#slide3').hide(); //初期では非表示

        $('#tags span').click(function() {

            if($(this).hasClass('active')){

                $('#slide3').hide();

                $($(this).find('#slide3').attr('href')).fadeOut();

                $('#slide3').removeClass('active');

            }else{

                $('#slide3').removeClass('active');

                $('#slide3').hide();
                $($(this).find('#slide3').attr('href')).fadeIn();

                $(this).addClass('active');

            }

        })

    });

    $(document).ready(function(){

        $('#slide4').hide(); //初期では非表示

        $('#tags span').click(function() {

            if($(this).hasClass('active')){

                $('#slide4').hide();

                $($(this).find('#slide4').attr('href')).fadeOut();

                $('#slide4').removeClass('active');

            }else{

                $('#slide4').removeClass('active');

                $('#slide4').hide();
                $($(this).find('#slide4').attr('href')).fadeIn();

                $(this).addClass('active');

            }

        })

    });

    $(document).ready(function(){

        $('#slide5').hide(); //初期では非表示

        $('#tags span').click(function() {

            if($(this).hasClass('active')){

                $('#slide5').hide();

                $($(this).find('#slide5').attr('href')).fadeOut();

                $('#slide5').removeClass('active');

            }else{

                $('#slide5').removeClass('active');

                $('#slide5').hide();
                $($(this).find('#slide5').attr('href')).fadeIn();

                $(this).addClass('active');

            }

        })

    });

        $(document).ready(function(){

        $('#slide6').hide(); //初期では非表示

        $('#tags span').click(function() {

            if($(this).hasClass('active')){

                $('#slide6').hide();

                $($(this).find('#slide6').attr('href')).fadeOut();

                $('#slide6').removeClass('active');

            }else{

                $('#slide6').removeClass('active');

                $('#slide6').hide();
                $($(this).find('#slide6').attr('href')).fadeIn();

                $(this).addClass('active');

            }

        })

    });

           $(document).ready(function(){

        $('#slide7').hide(); //初期では非表示

        $('#tags span').click(function() {

            if($(this).hasClass('active')){

                $('#slide7').hide();

                $($(this).find('#slide7').attr('href')).fadeOut();

                $('#slide7').removeClass('active');

            }else{

                $('#slide7').removeClass('active');

                $('#slide7').hide();
                $($(this).find('#slide7').attr('href')).fadeIn();

                $(this).addClass('active');

            }

        })

    });

           $(document).ready(function(){

        $('#slide8').hide(); //初期では非表示

        $('#tags span').click(function() {

            if($(this).hasClass('active')){

                $('#slide8').hide();

                $($(this).find('#slide8').attr('href')).fadeOut();

                $('#slide8').removeClass('active');

            }else{

                $('#slide8').removeClass('active');

                $('#slide8').hide();
                $($(this).find('#slide8').attr('href')).fadeIn();

                $(this).addClass('active');

            }

        })

    });

           $(document).ready(function(){

        $('#slide9').hide(); //初期では非表示

        $('#tags span').click(function() {

            if($(this).hasClass('active')){

                $('#slide9').hide();

                $($(this).find('#slide9').attr('href')).fadeOut();

                $('#slide9').removeClass('active');

            }else{

                $('#slide9').removeClass('active');

                $('#slide9').hide();
                $($(this).find('#slide9').attr('href')).fadeIn();

                $(this).addClass('active');

            }

        })

    });

           $(document).ready(function(){

        $('#slide10').hide(); //初期では非表示

        $('#tags span').click(function() {

            if($(this).hasClass('active')){

                $('#slide10').hide();

                $($(this).find('#slide10').attr('href')).fadeOut();

                $('#slide10').removeClass('active');

            }else{

                $('#slide10').removeClass('active');

                $('#slide10').hide();
                $($(this).find('#slide10').attr('href')).fadeIn();

                $(this).addClass('active');

            }

        })

    });

           $(document).ready(function(){

        $('#slide11').hide(); //初期では非表示

        $('#tags span').click(function() {

            if($(this).hasClass('active')){

                $('#slide11').hide();

                $($(this).find('#slide11').attr('href')).fadeOut();

                $('#slide11').removeClass('active');

            }else{

                $('#slide11').removeClass('active');

                $('#slide11').hide();
                $($(this).find('#slide11').attr('href')).fadeIn();

                $(this).addClass('active');

            }

        })

    });

           $(document).ready(function(){

        $('#slide12').hide(); //初期では非表示

        $('#tags span').click(function() {

            if($(this).hasClass('active')){

                $('#slide12').hide();

                $($(this).find('#slide12').attr('href')).fadeOut();

                $('#slide12').removeClass('active');

            }else{

                $('#slide12').removeClass('active');

                $('#slide12').hide();
                $($(this).find('#slide12').attr('href')).fadeIn();

                $(this).addClass('active');

            }

        })

    });

           $(document).ready(function(){

        $('#slide13').hide(); //初期では非表示

        $('#tags span').click(function() {

            if($(this).hasClass('active')){

                $('#slide13').hide();

                $($(this).find('#slide13').attr('href')).fadeOut();

                $('#slide13').removeClass('active');

            }else{

                $('#slide13').removeClass('active');

                $('#slide13').hide();
                $($(this).find('#slide13').attr('href')).fadeIn();

                $(this).addClass('active');

            }

        })

    });

           $(document).ready(function(){

        $('#slide14').hide(); //初期では非表示

        $('#tags span').click(function() {

            if($(this).hasClass('active')){

                $('#slide14').hide();

                $($(this).find('#slide14').attr('href')).fadeOut();

                $('#slide14').removeClass('active');

            }else{

                $('#slide14').removeClass('active');

                $('#slide14').hide();
                $($(this).find('#slide14').attr('href')).fadeIn();

                $(this).addClass('active');

            }

        })

    });

           $(document).ready(function(){

        $('#slide15').hide(); //初期では非表示

        $('#tags span').click(function() {

            if($(this).hasClass('active')){

                $('#slide15').hide();

                $($(this).find('#slide15').attr('href')).fadeOut();

                $('#slide15').removeClass('active');

            }else{

                $('#slide15').removeClass('active');

                $('#slide15').hide();
                $($(this).find('#slide15').attr('href')).fadeIn();

                $(this).addClass('active');

            }

        })

    });

    $(function(){

          var time=1500;
          var speed=1000;

          $("slide ul li").css({"posithon":"relative","overflow":"hidden"});
          $("slide ul li").hide().css({"posotion":"absolute","top":0,"left":0});
          $("slide ul li").addClass("active").show();

          setInterval(function(){

            var active = $("#slide ul li.active");

            var next = active.next("li").length?active.next("li"):$("#slide ul li:first");

            active.fadeOut(speed).removeClass("active");

            next.fadeIn(speed).addClass("active");
          },time)
          
    });


    $(function(){

          
          var time=1500;
          var speed=1000;

          $("slide2 ul li").css({"posithon":"relative","overflow":"hidden"});
          $("slide2 ul li").hide().css({"posotion":"absolute","top":0,"left":0});
          $("slide2 ul li").addClass("active").show();

          setInterval(function(){

            var active = $("#slide2 ul li.active");

            var next = active.next("li").length?active.next("li"):$("#slide2 ul li:first");

            active.fadeOut(speed).removeClass("active");

            next.fadeIn(speed).addClass("active");
          },time)
          
    });


     $(function(){

          
          var time=1500;
          var speed=1000;

          $("slide3 ul li").css({"posithon":"relative","overflow":"hidden"});
          $("slide3 ul li").hide().css({"posotion":"absolute","top":0,"left":0});
          $("slide3 ul li").addClass("active").show();

          setInterval(function(){

            var active = $("#slide3 ul li.active");

            var next = active.next("li").length?active.next("li"):$("#slide3 ul li:first");

            active.fadeOut(speed).removeClass("active");

            next.fadeIn(speed).addClass("active");
          },time)
          
      });

  $(function(){

          
          var time=1500;
          var speed=1000;

          $("slide4 ul li").css({"posithon":"relative","overflow":"hidden"});
          $("slide4 ul li").hide().css({"posotion":"absolute","top":0,"left":0});
          $("slide4 ul li").addClass("active").show();

          setInterval(function(){

            var active = $("#slide4 ul li.active");

            var next = active.next("li").length?active.next("li"):$("#slide4 ul li:first");

            active.fadeOut(speed).removeClass("active");

            next.fadeIn(speed).addClass("active");
          },time)
          
    });

    $(function(){

          
          var time=1500;
          var speed=1000;

          $("slide5 ul li").css({"posithon":"relative","overflow":"hidden"});
          $("slide5 ul li").hide().css({"posotion":"absolute","top":0,"left":0});
          $("slide5 ul li").addClass("active").show();

          setInterval(function(){

            var active = $("#slide5 ul li.active");

            var next = active.next("li").length?active.next("li"):$("#slide5 ul li:first");

            active.fadeOut(speed).removeClass("active");

            next.fadeIn(speed).addClass("active");
          },time)
          
    });

    $(function(){

          
          var time=1500;
          var speed=1000;

          $("slide6 ul li").css({"posithon":"relative","overflow":"hidden"});
          $("slide6 ul li").hide().css({"posotion":"absolute","top":0,"left":0});
          $("slide6 ul li").addClass("active").show();

          setInterval(function(){

            var active = $("#slide6 ul li.active");

            var next = active.next("li").length?active.next("li"):$("#slide6 ul li:first");

            active.fadeOut(speed).removeClass("active");

            next.fadeIn(speed).addClass("active");
          },time)
          
    });

    $(function(){

          
          var time=1500;
          var speed=1000;

          $("slide7 ul li").css({"posithon":"relative","overflow":"hidden"});
          $("slide7 ul li").hide().css({"posotion":"absolute","top":0,"left":0});
          $("slide7 ul li").addClass("active").show();

          setInterval(function(){

            var active = $("#slide7 ul li.active");

            var next = active.next("li").length?active.next("li"):$("#slide7 ul li:first");

            active.fadeOut(speed).removeClass("active");

            next.fadeIn(speed).addClass("active");
          },time)
          
    });

    $(function(){

          
          var time=1500;
          var speed=1000;

          $("slide8 ul li").css({"posithon":"relative","overflow":"hidden"});
          $("slide8 ul li").hide().css({"posotion":"absolute","top":0,"left":0});
          $("slide8 ul li").addClass("active").show();

          setInterval(function(){

            var active = $("#slide8 ul li.active");

            var next = active.next("li").length?active.next("li"):$("#slide8 ul li:first");

            active.fadeOut(speed).removeClass("active");

            next.fadeIn(speed).addClass("active");
          },time)
          
    });

    $(function(){

          
          var time=1500;
          var speed=1000;

          $("slide9 ul li").css({"posithon":"relative","overflow":"hidden"});
          $("slide9 ul li").hide().css({"posotion":"absolute","top":0,"left":0});
          $("slide9 ul li").addClass("active").show();

          setInterval(function(){

            var active = $("#slide9 ul li.active");

            var next = active.next("li").length?active.next("li"):$("#slide9 ul li:first");

            active.fadeOut(speed).removeClass("active");

            next.fadeIn(speed).addClass("active");
          },time)
          
    });
  
    $(function(){

          
          var time=1500;
          var speed=1000;

          $("slide10 ul li").css({"posithon":"relative","overflow":"hidden"});
          $("slide10 ul li").hide().css({"posotion":"absolute","top":0,"left":0});
          $("slide10 ul li").addClass("active").show();

          setInterval(function(){

            var active = $("#slide10 ul li.active");

            var next = active.next("li").length?active.next("li"):$("#slide10 ul li:first");

            active.fadeOut(speed).removeClass("active");

            next.fadeIn(speed).addClass("active");
          },time)
          
    });

    $(function(){

          
          var time=1500;
          var speed=1000;

          $("slide11 ul li").css({"posithon":"relative","overflow":"hidden"});
          $("slide11 ul li").hide().css({"posotion":"absolute","top":0,"left":0});
          $("slide11 ul li").addClass("active").show();

          setInterval(function(){

            var active = $("#slide11 ul li.active");

            var next = active.next("li").length?active.next("li"):$("#slide11 ul li:first");

            active.fadeOut(speed).removeClass("active");

            next.fadeIn(speed).addClass("active");
          },time)
          
    });

    $(function(){

          
          var time=1500;
          var speed=1000;

          $("slide12 ul li").css({"posithon":"relative","overflow":"hidden"});
          $("slide12 ul li").hide().css({"posotion":"absolute","top":0,"left":0});
          $("slide12 ul li").addClass("active").show();

          setInterval(function(){

            var active = $("#slide12 ul li.active");

            var next = active.next("li").length?active.next("li"):$("#slide12 ul li:first");

            active.fadeOut(speed).removeClass("active");

            next.fadeIn(speed).addClass("active");
          },time)
          
    });

    $(function(){

          
          var time=1500;
          var speed=1000;

          $("slide13 ul li").css({"posithon":"relative","overflow":"hidden"});
          $("slide13 ul li").hide().css({"posotion":"absolute","top":0,"left":0});
          $("slide13 ul li").addClass("active").show();

          setInterval(function(){

            var active = $("#slide13 ul li.active");

            var next = active.next("li").length?active.next("li"):$("#slide13 ul li:first");

            active.fadeOut(speed).removeClass("active");

            next.fadeIn(speed).addClass("active");
          },time)
          
    });

    $(function(){

          
          var time=1500;
          var speed=1000;

          $("slide14 ul li").css({"posithon":"relative","overflow":"hidden"});
          $("slide14 ul li").hide().css({"posotion":"absolute","top":0,"left":0});
          $("slide14 ul li").addClass("active").show();

          setInterval(function(){

            var active = $("#slide14 ul li.active");

            var next = active.next("li").length?active.next("li"):$("#slide14 ul li:first");

            active.fadeOut(speed).removeClass("active");

            next.fadeIn(speed).addClass("active");
          },time)
          
    });

    $(function(){

          
          var time=1500;
          var speed=1000;

          $("slide15 ul li").css({"posithon":"relative","overflow":"hidden"});
          $("slide15 ul li").hide().css({"posotion":"absolute","top":0,"left":0});
          $("slide15 ul li").addClass("active").show();

          setInterval(function(){

            var active = $("#slide15 ul li.active");

            var next = active.next("li").length?active.next("li"):$("#slide15 ul li:first");

            active.fadeOut(speed).removeClass("active");

            next.fadeIn(speed).addClass("active");
          },time)
          
    });

  $(function() {

    $("#tags span").click(function() {

      var tags = $(this).attr('id');
    $("#tags span").removeClass('select');
    $(this).addClass('select');
    $("#choice div").fadeOut(500);
      if(tags == 'tab02') {
          $("#choice .tab02").fadeIn(500);
      } else if(tags == 'tab01') {
          $("#choice .tab01").fadeIn(500);
      } else if(tags == 'tab03') {
          $("#choice .tab03").fadeIn(500);
      } else if(tags == 'tab04') {
          $("#choice .tab04").fadeIn(500);
      } else if(tags == 'tab05') {
          $("#choice .tab05").fadeIn(500);
      } else if(tags == 'tab06') {
          $("#choice .tab06").fadeIn(500);
      } else if(tags == 'tab07') {
          $("#choice .tab07").fadeIn(500);
      } else if(tags == 'tab08') {
          $("#choice .tab08").fadeIn(500);
      } else if(tags == 'tab09') {
          $("#choice .tab09").fadeIn(500);
      } else if(tags == 'tab10') {
          $("#choice .tab10").fadeIn(500);
      } else if(tags == 'tab11') {
          $("#choice .tab11").fadeIn(500);
      } else if(tags == 'tab12') {
          $("#choice .tab12").fadeIn(500);
      } else if(tags == 'tab13') {
          $("#choice .tab13").fadeIn(500);
      } else if(tags == 'tab14') {
          $("#choice .tab14").fadeIn(500);
      } else if(tags == 'tab15') {
          $("#choice .tab15").fadeIn(500);
      }  else {
          $("#choice div").fadeIn(500);
      }
    });
  });
